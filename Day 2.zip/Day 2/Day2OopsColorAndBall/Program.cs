﻿using System;

namespace Day2OopsColorAndBall
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create some colors
            Color redColor = new Color(255, 0, 0);
            Color greenColor = new Color(0, 255, 0);
            Color blueColor = new Color(0, 0, 255);

            // Create some balls
            Ball ball1 = new Ball(10, redColor);
            Ball ball2 = new Ball(15, greenColor);
            Ball ball3 = new Ball(20, blueColor);

            // Throw the balls
            ball1.Throw();
            ball1.Throw();
            ball2.Throw();
            ball2.Throw();
            ball2.Throw();
            ball3.Throw();

            // Pop a ball
            ball1.Pop();

            // Try throwing a popped ball
            ball1.Throw();

            // Print the throw counts
            Console.WriteLine("Ball 1 throw count: " + ball1.GetThrowCount());
            Console.WriteLine("Ball 2 throw count: " + ball2.GetThrowCount());
            Console.WriteLine("Ball 3 throw count: " + ball3.GetThrowCount());
        }
    }
}

