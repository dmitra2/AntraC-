﻿namespace Day2OopsConcept;

public class MethodQuestion1
{
    public void reverseNumbers()
    {
        int[] numbers = GenerateNumbers(10);
        Console.WriteLine("Original Array:");
        PrintNumbers(numbers);
        Reverse(numbers);
        Console.WriteLine("\nReversed Array:");
        PrintNumbers(numbers);
    }

    static int[] GenerateNumbers(int length)
    {
        int[] numbers = new int[length];
        for (int i = 0; i < length; i++)
        {
            numbers[i] = i + 1;
        }
        return numbers;
    }

    static void Reverse(int[] numbers)
    {
        int length = numbers.Length;
        for (int i = 0; i < length / 2; i++)
        {
            int temp = numbers[i];
            numbers[i] = numbers[length - i - 1];
            numbers[length - i - 1] = temp;
        }
    }

    static void PrintNumbers(int[] numbers)
    {
        foreach (int num in numbers)
        {
            Console.Write(num + " ");
        }
        Console.WriteLine();
    }
}