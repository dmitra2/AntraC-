﻿namespace Day2OopsConcept;

public class FibonacciCalculator
{
    public static int Fibonacci(int n)
    {
        if (n <= 2)
        {
            return 1;
        }
        else
        {
            return Fibonacci(n - 1) + Fibonacci(n - 2);
        }
    }
}
