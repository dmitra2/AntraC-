﻿using System;

namespace Day2OopsConcept
{
    class Program
    {
        public static void Main(String[] args)
        {   
            //Reversing Number
            MethodQuestion1 m = new MethodQuestion1();
            m.reverseNumbers();
            
            //Fibonnacci Calculator
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"Fibonacci({i}): {FibonacciCalculator.Fibonacci(i)}");
            }
        }
    }
}
    