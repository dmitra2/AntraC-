﻿namespace Strings;

using System;

class StrReverse
{
    public void ReversingString()
    {
        // Read the string from the console
        Console.WriteLine("Enter a string:");
        string input = Console.ReadLine();

        // Reverse the string using char array
        string reversedString1 = ReverseStringCharArray(input);

        // Reverse the string using a for-loop
        string reversedString2 = ReverseStringForLoop(input);

        // Print the reversed strings
        Console.WriteLine("Reversed string (using char array): " + reversedString1);
        Console.WriteLine("Reversed string (using for-loop): " + reversedString2);
    }

    // Method to reverse the string using char array
    static string ReverseStringCharArray(string input)
    {
        char[] charArray = input.ToCharArray();
        Array.Reverse(charArray);
        return new string(charArray);
    }

    // Method to reverse the string using a for-loop
    static string ReverseStringForLoop(string input)
    {
        string reversedString = "";
        for (int i = input.Length - 1; i >= 0; i--)
        {
            reversedString += input[i];
        }
        return reversedString;
    }
}
