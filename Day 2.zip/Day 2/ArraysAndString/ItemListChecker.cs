﻿namespace ArraysAndString;

public class ItemListChecker
{
    public void addRemoveItems()
    {
        List<string> itemList = new List<string>(); // Create a list to store items

        while (true) // Infinite loop
        {
            Console.WriteLine("Enter command (+ item, - item, or * to clear):");
            string input = Console.ReadLine().ToLower();

            if (string.IsNullOrWhiteSpace(input)) // Ignore empty input
                continue;

            char command = input[0]; // Get the first character of input

            switch (command)
            {
                case '+':
                    string itemToAdd = input.Substring(1).Trim().ToLower();
                    itemList.Add(itemToAdd);
                    break;
                case '-':
                    string itemToRemove = input.Substring(1).Trim();
                    itemList.Remove(itemToRemove);
                    break;
                case '*':
                    itemList.Clear();
                    break;
                
                //to stop the infinite loop
                case 'e' :
                    Console.WriteLine("Exiting the program ......");
                    return;
                
                default:
                    Console.WriteLine("Invalid command. Please use + to add, - to remove, or * to clear.");
                    break;
            }

            // Print current list
            Console.WriteLine("\nCurrent List:");
            foreach (string item in itemList)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        }
    }
}