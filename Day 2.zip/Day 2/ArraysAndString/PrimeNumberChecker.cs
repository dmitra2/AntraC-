﻿namespace ArraysAndString;

public class PrimeNumberChecker
{
    public int[] FindPrimesInRange(int startNum, int endNum)
    {
        List<int> primesList = new List<int>();

        for (int i = startNum; i <= endNum; i++)
        {
            if (IsPrime(i))
            {
                primesList.Add(i);
            }
        }

        return primesList.ToArray();
    }

    static bool IsPrime(int num)
    {
        if (num <= 1)
        {
            return false;
        }

        if (num == 2 || num == 3)
        {
            return true;
        }

        if (num % 2 == 0 || num % 3 == 0)
        {
            return false;
        }

        int divisor = 6;
        while (divisor * divisor - 2 * divisor + 1 <= num)
        {
            if (num % (divisor - 1) == 0 || num % (divisor + 1) == 0)
            {
                return false;
            }
            divisor += 6;
        }

        return true;
    }

}