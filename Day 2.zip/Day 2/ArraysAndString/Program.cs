﻿using System;

namespace ArraysAndString
{
    class Program
    {
        static void primeNumberChecker()
        {
            //Prime NumberChecker in Range
            Console.WriteLine("Enter the Start number");
            int startNumber = int.Parse(Console.ReadLine());


            Console.WriteLine("Enter the End number");
            int endNumber = int.Parse(Console.ReadLine());

            PrimeNumberChecker pn = new PrimeNumberChecker();
            if (startNumber < endNumber)
            {
                int[] primes = pn.FindPrimesInRange(startNumber, endNumber);

                Console.WriteLine($"Prime numbers between {startNumber} and {endNumber}:");
                foreach (int prime in primes)
                {
                    Console.Write(prime + " ");
                }
            }
            else
            {
                Console.WriteLine($"Start Number {startNumber} is lesser than end Number {endNumber}");
            }
        }
        
        static void Main(String[] args)
        {
            //Copy Array
            CopyArray c = new CopyArray();
            c.copyExistingArray();

            //Item List Checker
            ItemListChecker il = new ItemListChecker();
            il.addRemoveItems();

            // Prime NumberChecker
            primeNumberChecker();
            
            //LongestSequence of an Array
            LongestSequence l = new LongestSequence();
            l.longestSequenceofArray();
        }
    }

}


