﻿namespace ArraysAndString;

public class ArrayRotation
{
    public void rotateArray(int[] arr, int k)
    {
        int n = arr.Length;
        int[] sum = new int[n];
        int[] rotated = new int[n];

        for (int r = 1; r <= k; r++)
        {
            for (int i = 0; i < n; i++)
            {
                rotated[(i + r) % n] = arr[i];
            }

            Array.Copy(rotated, sum, n);
        }

        Console.WriteLine("Rotated Arrays:");
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write(rotated[j] + " ");
            }
            Console.WriteLine();
        }

        Console.WriteLine("Sum Array:");
        for (int i = 0; i < n; i++)
        {
            Console.Write(sum[i] + " ");
        }
    }
    
}