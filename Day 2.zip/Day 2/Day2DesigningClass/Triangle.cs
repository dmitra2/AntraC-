﻿namespace Day2DesigningClass;

public class Triangle : Shape
{
    // Constructor
    public Triangle(double width, double height) : base(width, height)
    {
    }

    // Polymorphism: Override method
    public override double CalculateArea()
    {
        return 0.5 * Width * Height;
    }
}