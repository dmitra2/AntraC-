﻿namespace Day2DesigningClass;

// Abstraction: Abstract class
public abstract class Shape
{
    // Encapsulation: Protected member variables
    protected double Width { get; set; }
    protected double Height { get; set; }

    // Constructor
    public Shape(double width, double height)
    {
        Width = width;
        Height = height;
    }

    // Abstract method
    public abstract double CalculateArea();
}
