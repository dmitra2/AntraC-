﻿using System;

namespace Day2DesigningClass
{
    class Program
    {
        static void Main(string[] args)
        {
            // Abstraction: Using abstract class
            Shape rectangle = new Rectangle(5, 4);
            Shape triangle = new Triangle(4, 3);

            // Polymorphism: Calling overridden methods
            Console.WriteLine($"Area of Rectangle: {rectangle.CalculateArea()}");
            Console.WriteLine($"Area of Triangle: {triangle.CalculateArea()}");
        }
    }
}

