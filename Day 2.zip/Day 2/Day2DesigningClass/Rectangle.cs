﻿namespace Day2DesigningClass;

// Inheritance: Derived classes
public class Rectangle : Shape
{
    // Constructor
    public Rectangle(double width, double height) : base(width, height)
    {
    }

    // Polymorphism: Override method
    public override double CalculateArea()
    {
        return Width * Height;
    }
}